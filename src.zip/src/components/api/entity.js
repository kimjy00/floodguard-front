
export default class Pin{
    constructor(no,lat,lng,name){
        this.no = no;
        this.lat = lat;
        this.lng = lng;
        this.name = name;
    }
}